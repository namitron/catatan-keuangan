$(document).ready(function () {
    $(".signup").click(function () {
        $(".img").animate({
            left: '378px'
        });
    });
});

$(document).ready(function () {
    $(".login").click(function () {
        $(".img").animate({
            left: '0'
        });
    });
});